export const GENRE = [
	{title: "Fiction", value: "fiction"},
	{title: "Non-Fiction", value: "non-fiction"},
	{title: "Thriller", value: "thriller"},
	{title: "Romance", value: "romance"},
	{title: "Sci-fi", value: "sci-fi"},
	{title: "Biography", value: "biography"},
	{title: "Comedy", value: "comedy"},
	{title: "Poetry", value: "poetry"},
	{title: "Self-help", value: "self-help"},
	{title: "Finance", value: "finance"},
	{title: "Travel", value: "travel"},
	{title: "Art", value: "art"},
]

export const BOOK_LENGTH = [
	{title: "Short Stories", value: "short-stories"},
	{title: "Novellas", value: "short-novels"},
	{title: "Novels", value: "novels"},
]
